//
//  DetailsViewController.swift
//  Apple News App
//
//  Created by Mohamed Ahmed Sadek on 3/26/19.
//  Copyright © 2019 IT Share. All rights reserved.
//

import UIKit
import Kingfisher

class DetailsViewController: UIViewController  {
    
    var article : Article!
    
   

    
    @IBOutlet weak var newsImage: UIImageView!
    @IBOutlet weak var newsTitle: UILabel!
    @IBOutlet weak var newsDescription: UITextView!
    @IBOutlet weak var authorLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        

        
        if let article = article {
          newsTitle.text = article.title
           newsDescription.text = article.description
            authorLabel.text = article.author
             dateLabel.text = article.publishedAt
            
          if let imageUrl = URL(string: article.urlToImage) {
             newsImage.kf.setImage(with: imageUrl)
            }
        }
    }
    



}
