//
//  ViewController.swift
//  Apple News App
//
//  Created by Mohamed Ahmed Sadek on 2/9/19.
//  Copyright © 2019 IT Share. All rights reserved.
//

import UIKit
import Alamofire
import Kingfisher



class AppleNewsViewController: UIViewController , UITableViewDelegate , UITableViewDataSource{

   
    @IBOutlet weak var searchTextField: UITextField!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var newsTableView: UITableView!
    var selectionPicker = UIPickerView()
    
    

    var  baseUrl = "https://newsapi.org/v2/everything"
    var apiKey = "50799fdf7ba64c4fb20c241899678415"
    var pageSize = 10
    var pageNumber = 1
    var totalResults = 0
    var returnedArticles : [Article] = []
    var searchEntities = ["apple","bitcoin"]
    var searchKey = ""
    //var num1 = 1
    //var num2 : Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        navigationController?.navigationBar.barTintColor = .red
         self.navigationItem.title = "News"
        
         newsTableView.delegate = self
         newsTableView.dataSource = self
        
          activityIndicator.hidesWhenStopped = true
        
           selectionPicker.delegate = self
            selectionPicker.dataSource = self
             searchTextField.inputView = selectionPicker
     }
    


    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let detailsVC = segue.destination as? DetailsViewController , let indexPathForSelectedRow = newsTableView.indexPathForSelectedRow {
            detailsVC.article = returnedArticles[indexPathForSelectedRow.row]
        }
    }
    
    
      // Table View Methods
      func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return returnedArticles.count
      }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
          let article = returnedArticles[indexPath.row]
            let cell = tableView.dequeueReusableCell(withIdentifier: "news", for: indexPath) as? NewsTableViewCell
        
          if let imageUrl = article.urlToImage , let url = URL(string : imageUrl) {
            cell?.newsImage.kf.indicatorType = .activity
             cell?.newsImage.kf.setImage(with: url)
          }
        
         cell?.titleLabel.text = article.title
          cell?.authorLabel.text = article.author
           cell?.dateLabel.text = article.publishedAt
        
            return cell!
      }
    
      func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 160
      }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "navigate", sender: self)
    }
    
   
    
    
    // Getting Data
    func getData(page :Int , completion : @escaping (Any) -> Void){
       
        
          activityIndicator.startAnimating()
            let parameters : [String: Any] = [
             "q" : searchKey,
              "sortBy" : "popularity",
               "pageSize" : pageSize,
                "page" : page
            ]
        
                 let headers: [String:String] = [
                    "X-Api-Key": apiKey
                ]

        Alamofire.request(baseUrl, method: .get, parameters: parameters, encoding: URLEncoding.default, headers: headers).responseJSON { (response) in
           
               DispatchQueue.main.async { [weak self] in
                self!.activityIndicator.stopAnimating()
               }
            
            print("URL .... \(String(describing: response.request?.url))")
            
                 if response.result.isSuccess {
                    print("Data retrieved successfully")
                     let data = response.result.value
                      completion(data!)
                  }  else {
                        print ("Error Found \(response.result.error!)")
                     }
              }
        }
    
   
    
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if indexPath.row == returnedArticles.count - 1 && totalResults > returnedArticles.count {
            pageNumber += 1
            
            getData(page: pageNumber){ [weak self](data) in
                if let dataDictionary = data as? [String : Any ]{
                    self!.totalResults = dataDictionary["totalResults"] as! Int
                
                    if let articles = dataDictionary["articles"] as? [[String:Any]] {
                        for anArticle in articles {
                          if let  articleObject = Parser.parse(articleData: anArticle){
                            self!.returnedArticles.append(articleObject)
                           }
                        }
                        DispatchQueue.main.async { [weak self] in
                            self!.newsTableView.reloadData()
                        }
                    }
                }
            }
        }
    }
}


   // configuring picker view data
   extension AppleNewsViewController : UIPickerViewDelegate , UIPickerViewDataSource {
      func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
      }
    
        func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return searchEntities.count
        }
    
         func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
              return searchEntities[row]
         }
    
    
     func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        searchTextField.text = searchEntities[row]
         searchKey = searchEntities[row]
        
            returnedArticles = []
            view.endEditing(true)
        
           getData(page: pageNumber ){ [weak self](data) in
            if let dataDictionary = data as? [String : Any ]{
                self!.totalResults = dataDictionary["totalResults"] as! Int
                
                if let articles = dataDictionary["articles"] as? [[String:Any]] {
                    for anArticle in articles {
                        if let  articleObject = Parser.parse(articleData: anArticle){
                            self!.returnedArticles.append(articleObject)
                        }
                    }
                    DispatchQueue.main.async {
                        self!.newsTableView.reloadData()
                    }
                }
            }
        }
    }
}
