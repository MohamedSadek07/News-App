//
//  Source.swift
//  Apple News App
//
//  Created by Mohamed Ahmed Sadek on 2/11/19.
//  Copyright © 2019 IT Share. All rights reserved.
//

import Foundation
class Source: Codable {
    var id : String!
    var name : String!
}
