//
//  Article.swift
//  Apple News App
//
//  Created by Mohamed Ahmed Sadek on 2/11/19.
//  Copyright © 2019 IT Share. All rights reserved.
//

import Foundation
class Article : Codable {
    var source : Source!
    var author : String!
    var title : String!
    var description : String!
    var url : String!
    var urlToImage : String!
    var publishedAt : String!
    var content : String!
}


