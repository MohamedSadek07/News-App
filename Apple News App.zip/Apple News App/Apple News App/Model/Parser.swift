//
//  Parser.swift
//  Apple News App
//
//  Created by Mohamed Ahmed Sadek on 2/11/19.
//  Copyright © 2019 IT Share. All rights reserved.
//

import Foundation
class Parser {
    
     class func data (json : Any?) -> Data? {
        guard json != nil else {return nil}
        
        do {
            return try JSONSerialization.data(withJSONObject: json!, options: .prettyPrinted)
            
        } catch {
            print(error)
            return nil
          }
       }
    
    
    class func parse(articleData : Any?) -> Article? {
        
        do {
        guard let data = self.data(json : articleData) else {return nil}
        return try JSONDecoder().decode(Article.self , from: data)
           
        } catch {
            print(error)    
            return nil
          }
     }
   
}



